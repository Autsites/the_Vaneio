CREATE FUNCTION criptografia (character varying) RETURNS character varying
	LANGUAGE plpgsql
AS $$
DECLARE
   v ALIAS FOR $1;
BEGIN
   RETURN md5(v);
END;

$$
